Trident file preview samples.
